# Pin npm packages by running ./bin/importmap

pin "application", preload: true
pin "rails-ujs", to: "https://ga.jspm.io/npm:rails-ujs@5.2.8-1/lib/assets/compiled/rails-ujs.js"
